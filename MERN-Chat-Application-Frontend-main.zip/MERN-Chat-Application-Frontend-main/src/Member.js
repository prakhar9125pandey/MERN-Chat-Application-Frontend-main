import React from "react";

function Member ({name}) {
    return <div className="member">
        <p>{name}</p>
    </div>
}

export default Member;